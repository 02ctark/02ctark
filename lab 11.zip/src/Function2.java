

import java.text.DecimalFormat;

public class Function2 extends Function{

	@Override
	public String answerString(double optVal, double x, double y, double z) {
		// TODO Auto-generated method stub
		
		DecimalFormat  d = new DecimalFormat("#,###,##.##");
		
		return " Minimum time is "+d.format(optVal) + "starting at point" + d.format(x);
	}
	

	@Override
	public String toString() {
		// TODO Auto-generated method stub
		return "Minimum speed with which a dog can run and swim to fetch the ball";
	}
	

	@Override
	public double fnValue(double x) {
		// TODO Auto-generated method stub
		return (x/3) + (2*Math.sqrt(Math.pow(x, 2) - (8*x) +25 ));
	}

	@Override
	public double getXVal(double x) {
		// TODO Auto-generated method stub
		return x;
	}

	@Override
	public double getYVal(double x) {
		// TODO Auto-generated method stub
		return -1;
	}

	@Override
	public double getZVal(double x) {
		// TODO Auto-generated method stub
		return -1;
	}

}
