

import java.text.DecimalFormat;

public class Function3 extends Function {

	@Override
	public String answerString(double optVal, double x, double y, double z) {
		// TODO Auto-generated method stub
		
		DecimalFormat d = new DecimalFormat("#,###,##0.##");
		return "Minimum distance from the point (0, 1) is = " + d.format(optVal) + " at ("+ 
				d.format(x) + ", " + d.format(y) + ") and ( " + d.format(-x)+ ","
				+ d.format(y)+")";
	}
	

	@Override
	public String toString() {
		// TODO Auto-generated method stub
		return "For the function x^2 and point (0,1) the minimum distance found by the distance formula.";
	}
	

	@Override
	public double fnValue(double x) {
		// TODO Auto-generated method stub
		return Math.sqrt(Math.pow(x, 4)-Math.pow(x, 2) + 1);
	}

	@Override
	public double getXVal(double x) {
		// TODO Auto-generated method stub
		return x;
	}

	@Override
	public double getYVal(double x) {
		// TODO Auto-generated method stub
		return Math.pow(x, 2);
	}

	@Override
	public double getZVal(double x) {
		// TODO Auto-generated method stub
		return -1;
	}

}
